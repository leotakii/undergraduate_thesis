#!/bin/sh

for D in *; do
    if [ -d "${D}" ]; then

    	cd ${D}/irace/ #entra na pasta do respectivo algoritmo

    	rm bestLogs #caso ja exista esse arquivo
    	echo  "message (\"RUNNING ${D}\")\n" > infile
    	touch bestLogs # cria o arquivo de saida

    	#R CMD BATCH [options] infile [outfile] & #sintaxe do comando

    	R CMD BATCH --no-save irace-run.R bestLogs &
        #R --no-save &
        echo "//PROCESSING/////${D}"
        cd ../../
    fi
done
