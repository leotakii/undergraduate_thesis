#!/bin/sh

       # make newlines the only separator
for i in $(cat < "$1"); do # j = parameters
	for j in $(cat < "$2"); do # j = parameters
		for k in $(cat < "$3"); do # k = randomSeed
	  	"$i" "$j" --randomSeed="$k"
	  	done
	done
done
